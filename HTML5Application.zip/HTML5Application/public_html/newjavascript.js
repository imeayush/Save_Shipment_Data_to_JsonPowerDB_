$(document).ready(function () {
    $("#empId").focus();

    // On Employee ID field blur, check if the ID exists in the database
    $("#empId").on("blur", checkEmployeeId);
});

// Function to check if Employee ID exists in the database
function checkEmployeeId() {
    var empId = $("#empId").val();
    if (empId === "") {
        alert("Employee ID is required.");
        $("#empId").focus();
        return;
    }
    var getReqStr = createGET_BY_KEYRequest("90934450|-31949229178159725|90956983", "EMP-DB", "EmpData", empId);
    jQuery.ajaxSetup({ async: false });
    var resultObj = executeCommandAtGivenBaseUrl(getReqStr, "http://api.login2explore.com:5577", "/api/irl");
    jQuery.ajaxSetup({ async: true });

    if (resultObj.status === 400) {
        // If Employee ID does not exist, enable Save and Reset buttons and all input fields except Employee ID
        enableFormForSave();
    } else {
        // If Employee ID exists, populate the form and enable Change and Reset buttons
        populateForm(resultObj.data);
        enableFormForChange();
    }
}

// Function to enable form for saving a new employee
function enableFormForSave() {
    $("#empName, #salary, #hra, #da, #deduction").prop("disabled", false);
    $("#saveBtn, #resetBtn").prop("disabled", false);
    $("#empId").prop("disabled", true);
    $("#empName").focus();
}

// Function to enable form for changing existing employee data
function enableFormForChange() {
    $("#empName, #salary, #hra, #da, #deduction").prop("disabled", false);
    $("#changeBtn, #resetBtn").prop("disabled", false);
    $("#saveBtn").prop("disabled", true);
    $("#empId").prop("disabled", true);
    $("#empName").focus();
}

// Function to reset the form to its initial state
function resetForm() {
    $("#empForm")[0].reset();
    $("#empId").prop("disabled", false).focus();
    $("#saveBtn, #changeBtn, #resetBtn").prop("disabled", true);
    $("#empName, #salary, #hra, #da, #deduction").prop("disabled", true);
}
